let album;
let sound;  // or a sound file, or an array of sounds, etc.

function preload() {
  album = loadImage('assets/Baile Inolvidable.jpg');
  sound = loadSound('assets/Aqui_Te_Espero_Track.mp3');  // or multiple sounds
}

function setup() {
  createCanvas(album.width, album.height);
  // If you want to ensure working with raw pixels:
  pixelDensity(1); //play with resolution here  
  image(album, 0, 0); //darw image at 0,0
  album.loadPixels(); 
}

function draw() {
  // Optionally, draw the image each frame (or just once in setup if not altering it)
  image(album, 0, 0);

  // get mouse coordinates relative to canvas
  let x = constrain(mouseX, 0, album.width - 1);
  let y = constrain(mouseY, 0, album.height - 1);

  // get pixel color at that spot **this can only happen if you load pixels which turn it into an array; 
  let c = album.get(x, y);  // returns [r, g, b, a] array :contentReference[oaicite:0]{index=0}

  // Example: map brightness or some function of color to sound volume, pitch, or triggering
  let brightness = (red(c) + green(c) + blue(c)) / 3;
  
  // Option A: play or control a single sound’s parameters
  if (! sound.isPlaying()) {
    sound.loop();
  }
  // Map brightness (0–255) to volume (0.0–1.0)
 let vol = map(brightness, 0, 255, 0, 1);
 sound.setVolume(vol);

  // Option B: you could map color channels to different parameters,
  // e.g. red -> playback rate, green -> volume, blue -> panning, etc.
  let speed = map(red(c), 0, 255, 1, 2);    // speed from 0.5x to 2x
  let pan = map(blue(c), 0, 255, -1, 1);      // stereo pan from left to right
  sound.rate(speed);//use sound.rate for any speed change of your stored sound var; 
  sound.pan(pan);

  // Optional: visual feedback
  noFill();
  stroke(255,0,0);
  strokeWeight(5)
  ellipse(x, y, 20, 20);
}

