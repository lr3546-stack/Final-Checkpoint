let fingers;
let particles = [];
let sound;
let txt = "AQUI TE ESPERO";
let fontSize = 50

function preload() {
  sound = loadSound('assets/Aqui_Te_Espero_Track.mp3');
  fingers = createVideo(['assets/Espero_rose_compressed.mp4']);
}

function setup() {
  createCanvas(windowWidth, windowHeight);

  fingers.loop();
  fingers.size(width, height);
  fingers.hide();

  sound.loop();

  textAlign(CENTER, CENTER);
  textSize(fontSize);
  
  
}

function draw() {
  background(255);

  // --- Draw video as rectangles/dots ---
  image(fingers, 0, 0, width, height);

  fingers.loadPixels();
  if (fingers.pixels.length > 0) {
    const stepSize = 15; // dot density
    for (let y = 0; y < height; y += stepSize) {
      for (let x = 0; x < width; x += stepSize) {
        const i = (y * width + x) * 4;
        let r = fingers.pixels[i];
        let g = fingers.pixels[i + 1];
        let b = fingers.pixels[i + 2];

        r = constrain(r * 1.2, 0, 255);
        g = constrain(g * 1.2, 0, 255);
        b = constrain(b * 1.2, 0, 255);

        const brightness = (r + g + b) / 3;
        const darkness = 1 - brightness / 255;

        let radius = stepSize * darkness * 1.3;
        fill(r, g, b);
        strokeWeight(0.5);
        if (dist(mouseX, mouseY, x, y) <= radius) {
          radius *= 2;
          fill(255);
        }
        rect(x, y, radius, radius);
      }
    }
  }

  // --- Audio speed based on brightness under mouse ---
  if (sound.isPlaying() && fingers.pixels.length > 0) {
    let mx = constrain(mouseX, 0, width - 1);
    let my = constrain(mouseY, 0, height - 1);
    let idx = (my * width + mx) * 4;
    let r = fingers.pixels[idx];
    let g = fingers.pixels[idx + 1];
    let b = fingers.pixels[idx + 2];
    let brightness = (r + g + b) / 3;
    let speed = map(brightness, 0, 255, 0.8, 1.2);
    sound.rate(speed);
  }

  // --- Spawn text particles at mouse click ---
  if (mouseIsPressed) {
    spawnTextParticles(mouseX, mouseY);
    text(txt,mouseX,mouseY);
  }

  // --- Update & show particles ---
  for (let i = particles.length - 1; i >= 0; i--) {
    let p = particles[i];
    let force = createVector(random(-0.2, 0.2), random(-0.2, 0.2));
    p.applyForce(force);
    p.update();
    p.show();

    if (p.isDead()) {
      particles.splice(i, 1);
    }
  }

  // --- Cursor indicator ---
  noFill();
  stroke(255);
  strokeWeight(2);
  ellipse(mouseX, mouseY, 20);
}

// --- Spawn particles forming text ---
function spawnTextParticles(mx, my) {
  if (!fingers.pixels.length) return;

  let pg = createGraphics(width, height);
  // pg.pixelDensity(1);
  // pg.background(0);
  // pg.textAlign(CENTER, CENTER);
  // pg.textSize(fontSize);
  // pg.fill(255);
  // // pg.text(txt, mx, my);
  // pg.loadPixels();

  const step = 6;

  for (let y = 0; y < pg.height; y += step) {
    for (let x = 0; x < pg.width; x += step) {
      const i = (y * pg.width + x) * 4;
      const alpha = pg.pixels[i + 3];
      if (alpha > 128) {
        const vi = (y * width + x) * 4;
        if (vi < fingers.pixels.length) {
          const r = fingers.pixels[vi];
          const g = fingers.pixels[vi + 1];
          const b = fingers.pixels[vi + 2];
          particles.push(new Particle(x, y, color(r, g, b)));
        }
      }
    }
  }
}

// --- Particle class ---
class Particle {
  constructor(x, y, col) {
    this.pos = createVector(x, y);
    this.vel = p5.Vector.random2D().mult(random(0.5, 2));
    this.acc = createVector();
    this.lifespan = 255;
    this.col = col;
  }

  applyForce(force) {
    this.acc.add(force);
  }

  update() {
    this.vel.add(this.acc);
    this.pos.add(this.vel);
    this.acc.mult(0);
    this.lifespan -= 2;
  }

  show() {
    noStroke();
    fill(red(this.col), green(this.col), blue(this.col), this.lifespan);
    ellipse(this.pos.x, this.pos.y, 4);
  }

  isDead() {
    return this.lifespan <= 0;
  }
}

